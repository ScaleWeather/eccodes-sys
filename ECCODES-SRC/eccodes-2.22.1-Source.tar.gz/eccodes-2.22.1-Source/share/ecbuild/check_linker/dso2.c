void fun1(void);
void fun2(void) { fun1(); }

